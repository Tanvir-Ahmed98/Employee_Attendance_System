<?php
$servername = "localhost";
$username = "myfeathe_portaladmin";
$password = "myfeatheportaladmin";
$dbname="myfeathe_portal";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

?>